from datetime import datetime
import csv
import yfinance as yf

def calculate_and_log_portfolio(holdings, csv_filename="portfolio_performance_log.csv"):
    """
    Calculates real-time portfolio valuation, individual and total gains/losses,
    and logs the performance snapshot to a CSV file.
    
    :param holdings: List of dictionaries containing 'ticker', 'buy_price', and 'quantity'
    :param csv_filename: Path to the output CSV log file
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    portfolio_summary = []
    
    total_investment = 0.0
    total_current_value = 0.0

    print(f"\n--- Portfolio Valuation Report ({timestamp}) ---")
    print(f"{'Ticker':<10} {'Qty':<8} {'Buy Price':<12} {'Current Price':<14} {'Current Value':<15} {'Gain/Loss (%)':<15}")
    print("-" * 75)

    for item in holdings:
        ticker = item["ticker"].upper()
        buy_price = float(item["buy_price"])
        quantity = int(item["quantity"])
        
        try:
            # Fetch real-time price using fast_info
            stock = yf.Ticker(ticker)
            current_price = stock.fast_info.get("last_price")
            
            if not current_price:
                # Fallback to historical data if fast_info is unavailable
                todays_data = stock.history(period="1d")
                if not todays_data.empty:
                    current_price = todays_data["Close"].iloc[-1]
                else:
                    raise ValueError("Unable to fetch price data.")
        except Exception as e:
            print(f"Error fetching data for {ticker}: {e}")
            continue

        investment_value = buy_price * quantity
        current_value = current_price * quantity
        gain_loss_amount = current_value - investment_value
        gain_loss_pct = (gain_loss_amount / investment_value) * 100 if investment_value > 0 else 0.0

        total_investment += investment_value
        total_current_value += current_value

        print(f"{ticker:<10} {quantity:<8} ₹{buy_price:<11.2f} ₹{current_price:<13.2f} ₹{current_value:<14.2f} {gain_loss_pct:+.2f}%")

        portfolio_summary.append({
            "Timestamp": timestamp,
            "Ticker": ticker,
            "Quantity": quantity,
            "Buy Price": round(buy_price, 2),
            "Current Price": round(current_price, 2),
            "Current Value": round(current_value, 2),
            "Gain/Loss (%)": round(gain_loss_pct, 2)
        })

    total_gain_loss = total_current_value - total_investment
    total_gain_loss_pct = (total_gain_loss / total_investment) * 100 if total_investment > 0 else 0.0

    print("-" * 75)
    print(f"Total Portfolio Investment: ₹{total_investment:,.2f}")
    print(f"Total Current Valuation:    ₹{total_current_value:,.2f}")
    print(f"Total Return:               ₹{total_gain_loss:+,.2f} ({total_gain_loss_pct:+.2f}%)\n")

    # Persist logs to CSV
    csv_columns = ["Timestamp", "Ticker", "Quantity", "Buy Price", "Current Price", "Current Value", "Gain/Loss (%)"]
    try:
        with open(csv_filename, mode="a", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=csv_columns)
            # Write header if file is empty
            if csv_file.tell() == 0:
                writer.writeheader()
            for row in portfolio_summary:
                writer.writerow(row)
        print(f"Performance logs successfully saved to {csv_filename}")
    except IOError as e:
        print(f"I/O error while writing to CSV: {e}")

# Example Usage:
if __name__ == "__main__":
    # Sample Indian stock tickers (use '.NS' for National Stock Exchange of India)
    my_holdings = [
        {"ticker": "RELIANCE.NS", "buy_price": 2450.00, "quantity": 15},
        {"ticker": "TCS.NS", "buy_price": 3500.00, "quantity": 10},
        {"ticker": "INFY.NS", "buy_price": 1400.00, "quantity": 25}
    ]
    
    calculate_and_log_portfolio(my_holdings)