import random

# ASCII Art stages for the gallows (6 attempts)
HANGMAN_STAGES = [
    """
       ------
       |    |
            |
            |
            |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
            |
            |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
       |    |
            |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
      /|    |
            |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
      /|\\   |
            |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
      /|\\   |
      /     |
            |
    ---------
    """,
    """
       ------
       |    |
       O    |
      /|\\   |
      / \\   |
            |
    ---------
    """
]

WORD_LIST = [
    "python", "developer", "terminal", "algorithm",
    "function", "variable", "debugging", "syntax", "modular"
]

def get_random_word():
    """Selects a random word from the predefined word list."""
    return random.choice(WORD_LIST)

def display_game_state(attempts_left, guessed_letters, current_word_state):
    """Renders the current visual state of the gallows and game progress."""
    stage_index = 6 - attempts_left
    print("\n" + "=" * 40)
    print(HANGMAN_STAGES[stage_index])
    print(f"Word: {' '.join(current_word_state)}")
    print(f"Attempts remaining: {attempts_left}")
    sorted_guesses = sorted(list(guessed_letters))
    print(f"Guessed letters: {', '.join(sorted_guesses) if sorted_guesses else 'None'}")
    print("=" * 40)

def play_hangman():
    """Main game loop managing state, input validation, and win/loss conditions."""
    word_to_guess = get_random_word()
    current_state = ["_"] * len(word_to_guess)
    guessed_letters = set()
    attempts_left = 6
    print("\nWelcome to Hangman!")
    print("Guess the hidden word letter by letter before you run out of attempts.")
    while attempts_left > 0 and "_" in current_state:
        display_game_state(attempts_left, guessed_letters, current_state)
        guess = input("Enter a letter: ").lower().strip()
        if not guess or len(guess) != 1 or not guess.isalpha():
            print("\n[!] Invalid input. Please enter a single alphabetical letter.")
            continue
        if guess in guessed_letters:
            print(f"\n[!] You already guessed '{guess}'. Try a different letter (no penalty).")
            continue
        guessed_letters.add(guess)
        if guess in word_to_guess:
            print(f"\nGood job! '{guess}' is in the word.")
            for index, char in enumerate(word_to_guess):
                if char == guess:
                    current_state[index] = guess
        else:
            attempts_left -= 1
            print(f"\nIncorrect! '{guess}' is not in the word.")
    print("\n" + "=" * 40)
    if "_" not in current_state:
        print(f"🎉 Congratulations! You guessed the word: {word_to_guess}")
    else:
        print(HANGMAN_STAGES[6])
        print(f"💀 Game Over! The hidden word was: {word_to_guess}")
    print("=" * 40)

if __name__ == "__main__":
    while True:
        play_hangman()
        replay = input("\nWould you like to play again? (y/n): ").lower().strip()
        if replay != 'y':
            print("\nThanks for playing!")
            break
