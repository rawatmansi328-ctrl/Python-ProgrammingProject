import datetime
import os
import pandas as pd
import yfinance as yf


def track_portfolio(holdings):
  """Calculates real-time portfolio valuation and logs performance to CSV.

  :param holdings: List of dicts with keys: 'ticker', 'buy_price', 'quantity'
  """
  portfolio_data = []
  total_investment = 0.0
  total_current_value = 0.0
  timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

  print(f"\n--- Portfolio Valuation Report ({timestamp}) ---\n")

  for item in holdings:
    ticker = item["ticker"].upper()
    buy_price = float(item["buy_price"])
    quantity = float(item["quantity"])

    try:
      # Fetch real-time market data
      stock = yf.Ticker(ticker)
      current_price = stock.fast_info.get("lastPrice")

      if not current_price:
        hist = stock.history(period="1d")
        if not hist.empty:
          current_price = hist["Close"].iloc[-1]
        else:
          raise ValueError(f"Could not retrieve price for {ticker}")

      investment = buy_price * quantity
      current_value = current_price * quantity
      gain_loss_amount = current_value - investment
      gain_loss_pct = (
          ((current_price - buy_price) / buy_price) * 100
          if buy_price > 0
          else 0.0
      )

      total_investment += investment
      total_current_value += current_value

      portfolio_data.append({
          "Timestamp": timestamp,
          "Ticker": ticker,
          "Quantity": quantity,
          "Buy Price": round(buy_price, 2),
          "Current Price": round(current_price, 2),
          "Investment Value": round(investment, 2),
          "Current Value": round(current_value, 2),
          "Gain/Loss (₹)": round(gain_loss_amount, 2),
          "Gain/Loss (%)": round(gain_loss_pct, 2),
      })

    except Exception as e:
      print(f"Error processing {ticker}: {e}")

  df = pd.DataFrame(portfolio_data)

  if not df.empty:
    print(df.to_string(index=False))
    total_gain_loss = total_current_value - total_investment
    total_gain_loss_pct = (
        (total_gain_loss / total_investment) * 100
        if total_investment > 0
        else 0.0
    )

    print("\n" + "=" * 60)
    print(f"Total Initial Investment: ₹{total_investment:,.2f}")
    print(f"Total Current Valuation:  ₹{total_current_value:,.2f}")
    print(
        f"Total Portfolio Return:   ₹{total_gain_loss:,.2f}"
        f" ({total_gain_loss_pct:.2f}%)"
    )
    print("=" * 60)

    # Persist logs to CSV (appends new logs with timestamp)
    csv_file = "portfolio_performance_log.csv"
    file_exists = os.path.exists(csv_file)
    df.to_csv(csv_file, mode="a", index=False, header=not file_exists)
    print(f"\nPerformance log successfully appended to '{csv_file}'.")
  else:
    print("No valid portfolio data processed.")


if __name__ == "__main__":
  # Example portfolio configuration using Indian NSE tickers
  sample_portfolio = [
      {"ticker": "RELIANCE.NS", "buy_price": 2450.0, "quantity": 15},
      {"ticker": "TCS.NS", "buy_price": 3400.0, "quantity": 10},
      {"ticker": "INFY.NS", "buy_price": 1450.0, "quantity": 25},
  ]
  track_portfolio(sample_portfolio)